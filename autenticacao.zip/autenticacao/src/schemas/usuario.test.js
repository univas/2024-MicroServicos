// Comparar um usuário válido

// Comparar usuário com e-mail inválido
    // Comparar usuário com e-mail vazio

// Comparar usuário com nome com menos de 05 caracteres
    // Comparar usuário com nome vazio

// Comparar usuário com senha com menos de 06 caracteres
    // Comparar usuário com senha vazia

// Comparar usuário sem nenhum dado